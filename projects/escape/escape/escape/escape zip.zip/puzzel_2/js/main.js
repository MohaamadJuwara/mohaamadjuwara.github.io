 function myFunction() {
    let ask = prompt("Wat is de code?");
const code = 267;
if (ask == code){
    alert("Je hebt de code goed!");
    document.location.href = '../puzzel_3/kraan.html';
}
else{
    alert('Je hebt de code fout!');
}
 }
 